<?php

namespace app\Config;

class DatabaseConfig
{
    public $host = "Localhost";
    public $user = "root";
    public $password = "";
    public $database_name = "codelabweb4";
    public $port = 3306;

}